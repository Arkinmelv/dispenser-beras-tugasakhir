<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Laporan_pembelian extends Model
{
    protected $table = "laporan_pembelian";
}
